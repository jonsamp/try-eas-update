module.exports = require('expo-module-scripts/jest-preset-plugin');
