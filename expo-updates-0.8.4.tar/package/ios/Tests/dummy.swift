// This dummy Swift file is to persuade Xcode to include Swift runtime,
// which is required when one of the dependency has some Swift code.
// Read more here: https://github.com/CocoaPods/CocoaPods/issues/7170#issuecomment-339815814
