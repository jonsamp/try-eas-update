import { NativeModulesProxy } from '@unimodules/core';
export default NativeModulesProxy.ExpoUpdates || ({} as any);
