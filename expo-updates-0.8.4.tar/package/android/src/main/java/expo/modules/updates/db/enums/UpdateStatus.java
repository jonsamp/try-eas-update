package expo.modules.updates.db.enums;

public enum UpdateStatus {
  FAILED, READY, LAUNCHABLE, PENDING, UNUSED, EMBEDDED, DEVELOPMENT
}
