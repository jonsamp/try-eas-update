package expo.modules.updates.db.enums;

public enum HashType {
  SHA256
}
